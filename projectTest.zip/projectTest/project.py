import subprocess

def capture_packets(output_file='capture.pcapng', duration=10):
    command= [
        "tshark",
        "-i", "any",
        "-a", f"duration:{duration}",
        "-w", output_file
    ]

    print(f"Running Command: {' '.join(command)}")
    subprocess.run(command)

if __name__ == "__main__":
    capture_packets()